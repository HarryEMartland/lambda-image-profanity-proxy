# Image Profanity Proxy

````
const algorithm = 'aes192';
const key = 'a password';
const cipher = crypto.createCipher(algorithm, key);
const url = "https://static.europcar.com/carvisuals/partners/835x557/ECMD_BE.png"

const encryptedUrl = cipher.update(url, 'utf8', 'hex') +
        cipher.final('hex');
        
console.log(encryptedUrl)
//b372ae6a49066dfcc1783878cc40502f3255c961aa1b80eb2520cf82fb145e7fc07a89e5a59231cce4a29f4b44f54e7f8c3adaf6067498c32068edcd9a08ac456e5281887cf546ddc100ea5c5bc50d1d
````

https://r3eba4lg07.execute-api.eu-west-1.amazonaws.com/prod/image?imageUrl=b372ae6a49066dfcc1783878cc40502f3255c961aa1b80eb2520cf82fb145e7fc07a89e5a59231cce4a29f4b44f54e7f8c3adaf6067498c32068edcd9a08ac456e5281887cf546ddc100ea5c5bc50d1d